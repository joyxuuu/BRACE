##########################
### MNN #################

#setwd("~/Box/Me/wife/dissertation/code/server/")
source("src/function.R")
source("src/MCMC.R")


# True parameter setting:

n_total <- 2000
K <- 4 # arm k=1 is control arm, arm k=2-4 are treatment
J <- 10 
nj <- n_total/J # n=200 in each stage 
ctrl_prop <- 1/4


## varying lambda in different groups
lambda_ctrl_true <- 0.2
lambda_medium_true <- 0.18
lambda_strong_true <- 0.15

#method_vec <- c("OF","pocock","power")
method = "pocock"
#omega_vec <- c(0.2,0.3)
omega_true <- 0.3 

### updated 08/26/2022

## D = 4-log(30-Y)*\tau
# according to Victor: log(22-Y) ~ N(0.77,0.8^2)

mu_ctrl_true <-  1.7  ## E(Y)=22 - exp(0.77)=19.84,  D=4-log(30-Y) = 4-2.32 = 1.68
sd_ctrl_true <- 0.8 ## sigma2=0.64

delta_strong <- 0.8 # strong effect size: Cohen's: 0.8
delta_medium <- 0.5 # weak effect size: Cohen's: 0.5

mu_strong_true <- mu_ctrl_true + (delta_strong*sd_ctrl_true)
mu_medium_true <- mu_ctrl_true + (delta_medium*sd_ctrl_true)
Y_ctrl_mean <- 28*omega_true + (1-omega_true)*(30-exp(-(mu_ctrl_true-4)))
Y_medium_mean <- 28*omega_true + (1-omega_true)*(30-exp(-(mu_medium_true-4)))
Y_strong_mean <- 28*omega_true + (1-omega_true)*(30-exp(-(mu_strong_true-4)))
Ydiff_medium <- Y_medium_mean - Y_ctrl_mean 
Ydiff_strong <- Y_strong_mean - Y_ctrl_mean


# MNN 
mu_trt1_true <- mu_medium_true # M
mu_trt2_true <- mu_ctrl_true # N
mu_trt3_true <- mu_ctrl_true # N
sd_trt1_true <- sd_trt2_true <- sd_trt3_true <- sd_ctrl_true
lambda_trt1_true <- lambda_medium_true # M
lambda_trt2_true <- lambda_ctrl_true # N
lambda_trt3_true <- lambda_ctrl_true # N

clin_Ydiff <- 1.5
#Y_ctrl <- 30- exp(-mu_ctrl_true)
#Y_trt <- Y_baseline + clin_Ydiff
#clin_diff <- log(Y_trt/Y_baseline)*(1-omega_true)*(1-lambda_ctrl)
Y_clin_mean <- Y_ctrl_mean  + clin_Ydiff
clin_diff <- log(Y_clin_mean/Y_ctrl_mean)

lb <- 4-log(30) ##
ub <- 4-log(2) ## 


#rar_crit <- crit_array["omega02","of",]
#tstp_crit <- crit_array["omega02","of",]

adapt_crit <- c(0.9895111, 0.9807556, 0.9737778, 0.9688889, 0.9567111, 0.9574222, 0.9529778,
                0.9433778, 0.9363111, 0.9335111)  # omega=0.3 pocock

tstp_crit <- c(0.9423111, 0.9226222, 0.9106222, 0.8960889, 0.8797333, 0.8666667, 0.8619111,
               0.8508444, 0.8282222, 0.8245778)   # omega=0.3


## times of replications, iterations, etc.

R <- 1000 # number of replications
B <- 2000 # number of MCMC iterations
burnin <- 500 # burnin iterations to remove
thin <- 10 # take every 10th sample from posterior

# Run the simulation for adaptive design at multiple stages:

all.start <- proc.time()

seed <- 123
set.seed(seed)

final_res_tp <- final_res_ts <- final_res_fr <- final_res_R1 <- final_res_R2 <- final_res_R3 <- array(NA,dim=c(length(seq(burnin+1,B,thin)),R,4*4),
                          dimnames=list(NULL,NULL,c("ctrl_mu","ctrl_sigma2","ctrl_omega","ctrl_lambda",
                                                                                                                                "trt1_mu","trt1_sigma2","trt1_omega","trt1_lambda",
                                                                                                                                "trt2_mu","trt2_sigma2","trt2_omega","trt2_lambda",
                                                                                                                                "trt3_mu","trt3_sigma2","trt3_omega","trt3_lambda")))

final_data_ctrl_tp <- final_data_trt1_tp <- final_data_trt2_tp <- final_data_trt3_tp <-
  final_data_ctrl_ts <- final_data_trt1_ts <- final_data_trt2_ts <- final_data_trt3_ts <-
  final_data_ctrl_fr <- final_data_trt1_fr <- final_data_trt2_fr <- final_data_trt3_fr <- final_data_ctrl_R1 <- final_data_trt1_R1 <- final_data_trt2_R1 <- final_data_trt3_R1 <- final_data_ctrl_R2 <- final_data_trt1_R2 <- final_data_trt2_R2 <- final_data_trt3_R2  <-final_data_ctrl_R3 <- final_data_trt1_R3 <- final_data_trt2_R3 <- final_data_trt3_R3 <- vector("list",length=R)


#sink(file = "res/logfile_snn_omega1_of_R1000.txt", type = "output")

for(r in 1:R){
  
  print(paste("Simulation",r,sep=" "))
  start <- proc.time()
  
  ### 1. our method and allocation rules
  
  # 1a. BayesRAR rule 1: control proportion fixed =1/4 
  
  print("BayesRAR Rule 1")
  
  #stage 1 
  j=1 
  
  print(paste("Stage",j,sep=" "))
  
  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop ## initial ss
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  
  data_ctrl <- sim_data_init(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
  data_trt1 <- sim_data_init(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
  data_trt2 <- sim_data_init(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true) 
  data_trt3 <- sim_data_init(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
  
  mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
  mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
  sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
  sd_ctrl <- sqrt(sigma2_ctrl)
  omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
  lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
  rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
  theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
  
  mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
  mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
  sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
  sd_trt1 <- sqrt(sigma2_trt1)
  omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
  lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
  rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
  theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
  
  mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
  mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
  sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
  sd_trt2 <- sqrt(sigma2_trt2)
  omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
  lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
  rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
  theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
  
  mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
  mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
  sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
  sd_trt3 <- sqrt(sigma2_trt3)
  omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
  lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
  rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
  theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
  
  data_ctrl_s1 <- data_ctrl
  data_trt1_s1 <- data_trt1
  data_trt2_s1 <- data_trt2
  data_trt3_s1 <- data_trt3
  
  theta_ctrl_s1 <- theta_ctrl
  theta_trt1_s1 <- theta_trt1
  theta_trt2_s1 <- theta_trt2
  theta_trt3_s1 <- theta_trt3
  
  p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
  p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
  p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
  
  pvec <- c(p1,p2,p3)
  #print(pvec)
  
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)] 
  
  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl
  datacur_trt1 <- data_trt1
  datacur_trt2 <- data_trt2
  datacur_trt3 <- data_trt3
  
  for(j in 2:J){
    
    if(any(p_diff>adapt_crit[j-1])) {
      # early stop for efficacy: P(theta_best - theta_ctrl > 1.5 ) > delta (e.g. alpha_crit) 
      
      final_data_ctrl_R1[[r]] <- datacur_ctrl
      final_data_trt1_R1[[r]] <- datacur_trt1
      final_data_trt2_R1[[r]] <- datacur_trt2
      final_data_trt3_R1[[r]] <- datacur_trt3
      
      final_res_R1[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_R1[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_R1[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_R1[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_R1[,r,"trt1_mu"] <- mu_trt1
      final_res_R1[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_R1[,r,"trt1_omega"] <- omega_trt1
      final_res_R1[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_R1[,r,"trt2_mu"] <- mu_trt2
      final_res_R1[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_R1[,r,"trt2_omega"] <- omega_trt2
      final_res_R1[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_R1[,r,"trt3_mu"] <- mu_trt3
      final_res_R1[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_R1[,r,"trt3_omega"] <- omega_trt3
      final_res_R1[,r,"trt3_lambda"] <- lambda_trt3
      ;
      break
    }
    
    # if any of p1, p2, p3 < 0.05, suspend that arm 
    if(p1<0.05) {
      n1=0
    }
    if(p2<0.05) {
      n2=0
    }
    if(p3<0.05) {
      n3=0
    }
    
    n0 = nj*ctrl_prop
    if(all(c(n1,n2,n3)!=0)){
      n1 = round((nj-n0)*p1/(p1+p2+p3))
      n2 = round((nj-n0)*p2/(p1+p2+p3))
      n3 = round((nj-n0)*p3/(p1+p2+p3))
    } else if(n1==0 & n2!=0 & n3!=0){
      n2 = round((nj-n0)*p2/(p2+p3))
      n3 = round((nj-n0)*p3/(p2+p3))
    } else if(n1!=0 & n2==0 & n3!=0){
      n1 = round((nj-n0)*p1/(p1+p3))
      n3 = round((nj-n0)*p3/(p1+p3))
    } else if(n1!=0 & n2!=0 & n3==0){
      n1 = round((nj-n0)*p1/(p1+p2))
      n2 = round((nj-n0)*p2/(p1+p2))
    } else if(n1==0 & n2==0 & n3!=0){
      n3 = nj-n0
    } else if(n1==0 & n2!=0 & n3==0){
      n2 = nj-n0
    } else if(n1!=0 & n2==0 & n3==0){
      n1 = nj-n0
    } else if(n1==0 & n2==0 & n3==0){
      break
    }
    
    print(paste("Stage",j,sep=" "))
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    #stage j
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
    p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
    p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
    
    pvec <- c(p1,p2,p3)
    #print(pvec)
    
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
    #clin_diff <- 1.5
    
    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
  } 
  
  final_data_ctrl_R1[[r]] <- datacur_ctrl
  final_data_trt1_R1[[r]] <- datacur_trt1
  final_data_trt2_R1[[r]] <- datacur_trt2
  final_data_trt3_R1[[r]] <- datacur_trt3
  
  final_res_R1[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_R1[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_R1[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_R1[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_R1[,r,"trt1_mu"] <- mu_trt1
  final_res_R1[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_R1[,r,"trt1_omega"] <- omega_trt1
  final_res_R1[,r,"trt1_lambda"] <- lambda_trt1  
  
  final_res_R1[,r,"trt2_mu"] <- mu_trt2
  final_res_R1[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_R1[,r,"trt2_omega"] <- omega_trt2
  final_res_R1[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_R1[,r,"trt3_mu"] <- mu_trt3
  final_res_R1[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_R1[,r,"trt3_omega"] <- omega_trt3
  final_res_R1[,r,"trt3_lambda"] <- lambda_trt3
  
  # 1b. BayesRAR rule 2: control proportion not fixed (control with average proportion after assigning best arm)
  
  print("BayesRAR Rule 2")
  print("Stage 1")

  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  theta_ctrl <- theta_ctrl_s1
  theta_trt1 <- theta_trt1_s1
  theta_trt2 <- theta_trt2_s1
  theta_trt3 <- theta_trt3_s1
  
  p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
  p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
  p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
  
  pvec <- c(p1,p2,p3)
  #print(pvec)
  
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)] 
  
  #clin_diff <- 1.5

  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff) 
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl <- data_ctrl_s1
  datacur_trt1 <- data_trt1 <- data_trt1_s1
  datacur_trt2 <- data_trt2 <- data_trt2_s1
  datacur_trt3 <- data_trt3 <- data_trt3_s1
  
  for(j in 2:J){
    
    if(any(p_diff>adapt_crit[j-1])) {
      # early stop for efficacy: P(theta_best - theta_ctrl > 1.5 ) > delta (e.g. alpha_crit) 
      
      final_data_ctrl_R2[[r]] <- datacur_ctrl
      final_data_trt1_R2[[r]] <- datacur_trt1
      final_data_trt2_R2[[r]] <- datacur_trt2
      final_data_trt3_R2[[r]] <- datacur_trt3
      
      final_res_R2[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_R2[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_R2[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_R2[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_R2[,r,"trt1_mu"] <- mu_trt1
      final_res_R2[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_R2[,r,"trt1_omega"] <- omega_trt1
      final_res_R2[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_R2[,r,"trt2_mu"] <- mu_trt2
      final_res_R2[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_R2[,r,"trt2_omega"] <- omega_trt2
      final_res_R2[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_R2[,r,"trt3_mu"] <- mu_trt3
      final_res_R2[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_R2[,r,"trt3_omega"] <- omega_trt3
      final_res_R2[,r,"trt3_lambda"] <- lambda_trt3
      
      ;
      break
    }
    
    # if any of p1, p2, p3 < 0.05, suspend that arm 
    if(p1<0.05) {
      n1=0
    }
    if(p2<0.05) {
      n2=0
    }
    if(p3<0.05) {
      n3=0
    }
    
    
    ## specific to rule 2 
    
    cap <- round(nj*0.8)
    
    if(all(c(n1,n2,n3)!=0)){
      nvec <- rep(NA,3)
      pvec <- c(p1,p2,p3)
      pnorm <- pvec/sum(pvec)
      
      pbest <- max(pnorm)
      nvec[which.max(pnorm)] <- min(round(nj*pbest),cap)
      
      n0 = round((nj - nvec[which.max(pnorm)])*(1/3))
      
      nvec[-which.max(pnorm)] <- round((nj - nvec[which.max(pnorm)]-n0)*(pnorm[-which.max(pnorm)]/sum(pnorm[-which.max(pnorm)])))
      
      n1 = nvec[1]
      n2 = nvec[2]
      n3 = nvec[3]
      
    } else if(n1==0 & n2!=0 & n3!=0){
      
      nvec <- rep(NA,2)
      pvec <- c(p2,p3)
      pnorm <- pvec/sum(pvec)
      
      pbest <- max(pnorm)
      nvec[which.max(pnorm)] <- min(round(nj*pbest),cap)
      
      n0 = round((nj - nvec[which.max(pnorm)])*(1/2))
      
      nvec[-which.max(pnorm)] <- nj - nvec[which.max(pnorm)]-n0
      
      n2 = nvec[1]
      n3 = nvec[2]
      
    } else if(n1!=0 & n2==0 & n3!=0){
      
      nvec <- rep(NA,2)
      pvec <- c(p1,p3)
      pnorm <- pvec/sum(pvec)
      
      pbest <- max(pnorm)
      nvec[which.max(pnorm)] <- min(round(nj*pbest),cap)
      
      n0 = round((nj - nvec[which.max(pnorm)])*(1/2))
      
      nvec[-which.max(pnorm)] <- nj - nvec[which.max(pnorm)]-n0
      
      n1 = nvec[1]
      n3 = nvec[2]
      
    } else if(n1!=0 & n2!=0 & n3==0){
      
      nvec <- rep(NA,2)
      pvec <- c(p1,p2)
      pnorm <- pvec/sum(pvec)
      
      pbest <- max(pnorm)
      nvec[which.max(pnorm)] <- min(round(nj*pbest),cap)
      
      n0 = round((nj - nvec[which.max(pnorm)])*(1/2))
      
      nvec[-which.max(pnorm)] <- nj - nvec[which.max(pnorm)]-n0
      
      n1 = nvec[1]
      n2 = nvec[2]
      
    } else if(n1==0 & n2==0 & n3!=0){
      
      n3 = min(round(nj*p3),cap)
      n0 = nj - n3
      
    } else if(n1==0 & n2!=0 & n3==0){
      
      n2 = min(round(nj*p2),cap)
      n0 = nj - n2
      
    } else if(n1!=0 & n2==0 & n3==0){
      
      n1 = min(round(nj*p1),cap)
      n0 = nj - n1
      
    } else if(n1==0 & n2==0 & n3==0){
      break
    }
    
    print(paste("Stage",j,sep=" "))
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    #stage j
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
    p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
    p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
    
    pvec <- c(p1,p2,p3)
    #print(pvec)
    
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
    #clin_diff <- 1.5
    
    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
  } 
  
  
  final_data_ctrl_R2[[r]] <- datacur_ctrl
  final_data_trt1_R2[[r]] <- datacur_trt1
  final_data_trt2_R2[[r]] <- datacur_trt2
  final_data_trt3_R2[[r]] <- datacur_trt3
  
  final_res_R2[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_R2[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_R2[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_R2[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_R2[,r,"trt1_mu"] <- mu_trt1
  final_res_R2[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_R2[,r,"trt1_omega"] <- omega_trt1
  final_res_R2[,r,"trt1_lambda"] <- lambda_trt1
  
  final_res_R2[,r,"trt2_mu"] <- mu_trt2
  final_res_R2[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_R2[,r,"trt2_omega"] <- omega_trt2
  final_res_R2[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_R2[,r,"trt3_mu"] <- mu_trt3
  final_res_R2[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_R2[,r,"trt3_omega"] <- omega_trt3
  final_res_R2[,r,"trt3_lambda"] <- lambda_trt3
  
  
  # 1c. BayesRAR rule 3: control vs. best arm proportion = 1:1
  
  print("BayesRAR Rule 3")
  print("Stage 1")

  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  theta_ctrl <- theta_ctrl_s1
  theta_trt1 <- theta_trt1_s1
  theta_trt2 <- theta_trt2_s1
  theta_trt3 <- theta_trt3_s1
  
  p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
  p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
  p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
  
  
  pvec <- c(p1,p2,p3)
  #print(pvec)
  
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)] 
  
  #clin_diff <- 1.5
  
  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff) 
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl <- data_ctrl_s1
  datacur_trt1 <- data_trt1 <- data_trt1_s1
  datacur_trt2 <- data_trt2 <- data_trt2_s1
  datacur_trt3 <- data_trt3 <- data_trt3_s1
  
  
  for(j in 2:J){
    
    if(any(p_diff>adapt_crit[j-1])) {
      # early stop for efficacy: P(theta_best - theta_ctrl > 1.5 ) > delta (e.g. alpha_crit)       
      final_data_ctrl_R3[[r]] <- datacur_ctrl
      final_data_trt1_R3[[r]] <- datacur_trt1
      final_data_trt2_R3[[r]] <- datacur_trt2
      final_data_trt3_R3[[r]] <- datacur_trt3
      
      final_res_R3[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_R3[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_R3[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_R3[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_R3[,r,"trt1_mu"] <- mu_trt1
      final_res_R3[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_R3[,r,"trt1_omega"] <- omega_trt1
      final_res_R3[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_R3[,r,"trt2_mu"] <- mu_trt2
      final_res_R3[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_R3[,r,"trt2_omega"] <- omega_trt2
      final_res_R3[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_R3[,r,"trt3_mu"] <- mu_trt3
      final_res_R3[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_R3[,r,"trt3_omega"] <- omega_trt3
      final_res_R3[,r,"trt3_lambda"] <- lambda_trt3
      
      ;
      break
    }
    
    # if any of p1, p2, p3 < 0.05, suspend that arm 
    if(p1<0.05) {
      n1=0
    }
    if(p2<0.05) {
      n2=0
    }
    if(p3<0.05) {
      n3=0
    }
    
    
    ## specific to rule 3
    
    if(all(c(n1,n2,n3)!=0)){
      
      pvec <- c(p1,p2,p3)
      pnorm <- pvec/sum(pvec)
      pbest <- max(pnorm)
      scale_factor <- 1/pbest
      
      p0 <- pbest 
      pvec2 <- c(p0,pnorm)
      pvec2[-1][-which.max(pnorm)] <- scale_factor*pnorm[-which.max(pnorm)]
      pnorm2 <- pvec2/sum(pvec2)
      
      n0 = round(nj*pnorm2[1])
      n1 = round(nj*pnorm2[2])
      n2 = round(nj*pnorm2[3])
      n3 = round(nj*pnorm2[4])
      
    } else if(n1==0 & n2!=0 & n3!=0){
      
      pvec <- c(p2,p3)
      pnorm <- pvec/sum(pvec)
      pbest <- max(pnorm)
      scale_factor <- 1/pbest
      
      p0 <- pbest 
      pvec2 <- c(p0,pnorm)
      pvec2[-1][-which.max(pnorm)] <- scale_factor*pnorm[-which.max(pnorm)]
      pnorm2 <- pvec2/sum(pvec2)
      
      n0 = round(nj*pnorm2[1])
      n2 = round(nj*pnorm2[2])
      n3 = round(nj*pnorm2[3])
      
    } else if(n1!=0 & n2==0 & n3!=0){
      
      pvec <- c(p1,p3)
      pnorm <- pvec/sum(pvec)
      pbest <- max(pnorm)
      scale_factor <- 1/pbest
      
      p0 <- pbest 
      pvec2 <- c(p0,pnorm)
      pvec2[-1][-which.max(pnorm)] <- scale_factor*pnorm[-which.max(pnorm)]
      pnorm2 <- pvec2/sum(pvec2)
      
      n0 = round(nj*pnorm2[1])
      n1 = round(nj*pnorm2[2])
      n3 = round(nj*pnorm2[3])
      
    } else if(n1!=0 & n2!=0 & n3==0){
      
      pvec <- c(p1,p2)
      pnorm <- pvec/sum(pvec)
      pbest <- max(pnorm)
      scale_factor <- 1/pbest
      
      p0 <- pbest 
      pvec2 <- c(p0,pnorm)
      pvec2[-1][-which.max(pnorm)] <- scale_factor*pnorm[-which.max(pnorm)]
      pnorm2 <- pvec2/sum(pvec2)
      
      n0 = round(nj*pnorm2[1])
      n1 = round(nj*pnorm2[2])
      n2 = round(nj*pnorm2[3])
      
    } else if(n1==0 & n2==0 & n3!=0){
      
      n0 = n3 = nj*(1/2)
      
    } else if(n1==0 & n2!=0 & n3==0){
      
      n0 = n2 = nj*(1/2)
      
    } else if(n1!=0 & n2==0 & n3==0){
      
      n0 = n1 = nj*(1/2)
      
    } else if(n1==0 & n2==0 & n3==0){
      break
    }
    
    print(paste("Stage",j,sep=" "))
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    #stage j
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    p1 <- prob_best_3trtarm(theta_trt1,theta_trt2,theta_trt3)
    p2 <- prob_best_3trtarm(theta_trt2,theta_trt1,theta_trt3)
    p3 <- prob_best_3trtarm(theta_trt3,theta_trt1,theta_trt2)
    
    pvec <- c(p1,p2,p3)
    #print(pvec)
    
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
    #clin_diff <- 1.5
    
    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
    
  } 
  
  final_data_ctrl_R3[[r]] <- datacur_ctrl
  final_data_trt1_R3[[r]] <- datacur_trt1
  final_data_trt2_R3[[r]] <- datacur_trt2
  final_data_trt3_R3[[r]] <- datacur_trt3
  
  final_res_R3[,r,"trt1_mu"] <- mu_trt1
  final_res_R3[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_R3[,r,"trt1_omega"] <- omega_trt1
  final_res_R3[,r,"trt1_lambda"] <- lambda_trt1
  
  final_res_R3[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_R3[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_R3[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_R3[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_R3[,r,"trt2_mu"] <- mu_trt2
  final_res_R3[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_R3[,r,"trt2_omega"] <- omega_trt2
  final_res_R3[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_R3[,r,"trt3_mu"] <- mu_trt3
  final_res_R3[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_R3[,r,"trt3_omega"] <- omega_trt3
  final_res_R3[,r,"trt3_lambda"] <- lambda_trt3
  
  
  ### 2. fixed randomization (FR) allocation rule
  
  print("FR")
  print("Stage 1")

  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  p_fr <- fixed(K)
  #print(p_fr)
  
  theta_ctrl <- theta_ctrl_s1
  theta_trt1 <- theta_trt1_s1
  theta_trt2 <- theta_trt2_s1
  theta_trt3 <- theta_trt3_s1
  
  theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)] 
  
  #clin_diff <- 1.5

  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff) 
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl <- data_ctrl_s1
  datacur_trt1 <- data_trt1 <- data_trt1_s1
  datacur_trt2 <- data_trt2 <- data_trt2_s1
  datacur_trt3 <- data_trt3 <- data_trt3_s1
  
  for(j in 2:J){
    
    
    if(any(p_diff>tstp_crit[j-1])) { ## keep the same as BayesRAR
      
      final_data_ctrl_ts[[r]] <- datacur_ctrl
      final_data_trt1_ts[[r]] <- datacur_trt1
      final_data_trt2_ts[[r]] <- datacur_trt2
      final_data_trt3_ts[[r]] <- datacur_trt3
      
      final_res_ts[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_ts[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_ts[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_ts[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_ts[,r,"trt1_mu"] <- mu_trt1
      final_res_ts[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_ts[,r,"trt1_omega"] <- omega_trt1
      final_res_ts[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_ts[,r,"trt2_mu"] <- mu_trt2
      final_res_ts[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_ts[,r,"trt2_omega"] <- omega_trt2
      final_res_ts[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_ts[,r,"trt3_mu"] <- mu_trt3
      final_res_ts[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_ts[,r,"trt3_omega"] <- omega_trt3
      final_res_ts[,r,"trt3_lambda"] <- lambda_trt3
      
      ;
      break
    }
    
    ## no arm suspension for FR
    
    n0 = round(nj*p_fr[1])
    n1 = round(nj*p_fr[2])
    n2 = round(nj*p_fr[3])
    n3 = round(nj*p_fr[4])
    
    print(paste("Stage",j,sep=" "))
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    p_fr <- fixed(K)
    #print(p_fr)
    
    theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
    #clin_diff <- 1.5

    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
  }
  
  final_data_ctrl_fr[[r]] <- datacur_ctrl
  final_data_trt1_fr[[r]] <- datacur_trt1
  final_data_trt2_fr[[r]] <- datacur_trt2
  final_data_trt3_fr[[r]] <- datacur_trt3
  
  final_res_fr[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_fr[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_fr[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_fr[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_fr[,r,"trt1_mu"] <- mu_trt1
  final_res_fr[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_fr[,r,"trt1_omega"] <- omega_trt1
  final_res_fr[,r,"trt1_lambda"] <- lambda_trt1
  
  final_res_fr[,r,"trt2_mu"] <- mu_trt2
  final_res_fr[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_fr[,r,"trt2_omega"] <- omega_trt2
  final_res_fr[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_fr[,r,"trt3_mu"] <- mu_trt3
  final_res_fr[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_fr[,r,"trt3_omega"] <- omega_trt3
  final_res_fr[,r,"trt3_lambda"] <- lambda_trt3
  
 
  
  
  ### 3. Thompson sampling (ts) allocation rule
  
  print("TS")
  print("Stage 1")

  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  theta_ctrl <- theta_ctrl_s1
  theta_trt1 <- theta_trt1_s1
  theta_trt2 <- theta_trt2_s1
  theta_trt3 <- theta_trt3_s1
  
  
  theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
  pvec <- thompson(theta,j=1,nj,n_total)
  #print(pvec)
  
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)] 
  
  #clin_diff <- 1.5

  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff) 
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl <- data_ctrl_s1
  datacur_trt1 <- data_trt1 <- data_trt1_s1
  datacur_trt2 <- data_trt2 <- data_trt2_s1
  datacur_trt3 <- data_trt3 <- data_trt3_s1
  
  for(j in 2:J){
    
    # if any of p2, p3, p4 > 0.9, early stop for efficacy
    # if(any(pvec>0.95)) { ## subject to change, need to find critical value by e.g. permutation
    if(any(p_diff>tstp_crit[j-1])) { ## keep the same as BayesRAR
      
      final_data_ctrl_ts[[r]] <- datacur_ctrl
      final_data_trt1_ts[[r]] <- datacur_trt1
      final_data_trt2_ts[[r]] <- datacur_trt2
      final_data_trt3_ts[[r]] <- datacur_trt3
      
      final_res_ts[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_ts[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_ts[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_ts[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_ts[,r,"trt1_mu"] <- mu_trt1
      final_res_ts[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_ts[,r,"trt1_omega"] <- omega_trt1
      final_res_ts[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_ts[,r,"trt2_mu"] <- mu_trt2
      final_res_ts[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_ts[,r,"trt2_omega"] <- omega_trt2
      final_res_ts[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_ts[,r,"trt3_mu"] <- mu_trt3
      final_res_ts[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_ts[,r,"trt3_omega"] <- omega_trt3
      final_res_ts[,r,"trt3_lambda"] <- lambda_trt3
      
      ;
      break
    }
    
    # if any of p1, p2, p3 < 0.05, suspend that arm 
    p1 <- pvec[2]; p2 <- pvec[3]; p3 <- pvec[4] 
    
    if(p1<0.05) {
      n1=0
    }
    if(p2<0.05) {
      n2=0
    }
    if(p3<0.05) {
      n3=0
    }
    
    n0 = round(nj*pvec[1])
    n1 = round(nj*pvec[2])
    n2 = round(nj*pvec[3])
    n3 = round(nj*pvec[4])
    
    print(paste("Stage",j,sep=" "))
    
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    #stage j
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
    pvec <- thompson(theta,j,nj,n_total)
    #print(pvec)
    
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
  
    #clin_diff <- 1.5

    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
  }
  
  final_data_ctrl_ts[[r]] <- datacur_ctrl
  final_data_trt1_ts[[r]] <- datacur_trt1
  final_data_trt2_ts[[r]] <- datacur_trt2
  final_data_trt3_ts[[r]] <- datacur_trt3
  
  final_res_ts[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_ts[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_ts[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_ts[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_ts[,r,"trt1_mu"] <- mu_trt1
  final_res_ts[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_ts[,r,"trt1_omega"] <- omega_trt1
  final_res_ts[,r,"trt1_lambda"] <- lambda_trt1 
  
  final_res_ts[,r,"trt2_mu"] <- mu_trt2
  final_res_ts[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_ts[,r,"trt2_omega"] <- omega_trt2
  final_res_ts[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_ts[,r,"trt3_mu"] <- mu_trt3
  final_res_ts[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_ts[,r,"trt3_omega"] <- omega_trt3
  final_res_ts[,r,"trt3_lambda"] <- lambda_trt3
  
  ### 4. Trippa procedure (tp) allocation rule
  
  print("TP")
  print("Stage 1")

  n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop ## initial ss
  
  print(n0)
  print(n1)
  print(n2)
  print(n3)
  
  
  theta_ctrl <- theta_ctrl_s1
  theta_trt1 <- theta_trt1_s1
  theta_trt2 <- theta_trt2_s1
  theta_trt3 <- theta_trt3_s1
  
  theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
  n_cur <- c(nrow(data_ctrl_s1),nrow(data_trt1_s1),
             nrow(data_trt2_s1),nrow(data_trt3_s1))
  pvec <- trippa(theta,j=1,nj,n_total,n_cur=n_cur)
  #print(pvec)
  
  theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
  theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
  theta_best <- theta_mat[,which.max(theta_mean)]
  
  #clin_diff <- 1.5

  p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff) 
  #print(p_diff)
  
  datacur_ctrl <- data_ctrl <- data_ctrl_s1
  datacur_trt1 <- data_trt1 <- data_trt1_s1
  datacur_trt2 <- data_trt2 <- data_trt2_s1
  datacur_trt3 <- data_trt3 <- data_trt3_s1
  
  for(j in 2:J){
    
    # if any of p2, p3, p4 > 0.95, early stop for efficacy
    # if(any(pvec>0.95)) { ## subject to change, need to find critical value by e.g. permutation
    if(any(p_diff>tstp_crit[j-1])) { ## keep the same as BayesRAR
      
      final_data_ctrl_tp[[r]] <- datacur_ctrl
      final_data_trt1_tp[[r]] <- datacur_trt1
      final_data_trt2_tp[[r]] <- datacur_trt2
      final_data_trt3_tp[[r]] <- datacur_trt3
  
      final_res_tp[,r,"ctrl_mu"] <- mu_ctrl 
      final_res_tp[,r,"ctrl_sigma2"] <- sigma2_ctrl 
      final_res_tp[,r,"ctrl_omega"] <- omega_ctrl 
      final_res_tp[,r,"ctrl_lambda"] <- lambda_ctrl
      
      final_res_tp[,r,"trt1_mu"] <- mu_trt1
      final_res_tp[,r,"trt1_sigma2"] <- sigma2_trt1
      final_res_tp[,r,"trt1_omega"] <- omega_trt1
      final_res_tp[,r,"trt1_lambda"] <- lambda_trt1
      
      final_res_tp[,r,"trt2_mu"] <- mu_trt2
      final_res_tp[,r,"trt2_sigma2"] <- sigma2_trt2
      final_res_tp[,r,"trt2_omega"] <- omega_trt2
      final_res_tp[,r,"trt2_lambda"] <- lambda_trt2
      
      final_res_tp[,r,"trt3_mu"] <- mu_trt3
      final_res_tp[,r,"trt3_sigma2"] <- sigma2_trt3
      final_res_tp[,r,"trt3_omega"] <- omega_trt3
      final_res_tp[,r,"trt3_lambda"] <- lambda_trt3
      
      ;
      break
    }
    
    # if any of p2, p3, p4 < 0.05, suspend that arm 
    p1 <- pvec[2]; p2 <- pvec[3]; p3 <- pvec[4] 
    
    if(p1<0.05) {
      n1=0
    }
    if(p2<0.05) {
      n2=0
    }
    if(p3<0.05) {
      n3=0
    }
    
    n0 = round(nj*pvec[1])
    n1 = round(nj*pvec[2])
    n2 = round(nj*pvec[3])
    n3 = round(nj*pvec[4])
    
    print(paste("Stage",j,sep=" "))
    
    print(n0)
    print(n1)
    print(n2)
    print(n3)
    
    #stage j
    
    if(n0!=0){
      dataj_ctrl <- sim_data(n=n0,mu=mu_ctrl_true,sd=sd_ctrl_true,
                             omega=omega_true,lambda=lambda_ctrl_true)
    } else{
      dataj_ctrl <- NULL }
    
    if(n1!=0){
      dataj_trt1 <- sim_data(n=n1,mu=mu_trt1_true,sd=sd_trt1_true,
                             omega=omega_true,lambda=lambda_trt1_true) 
    } else{
      dataj_trt1 <- NULL } 
    
    if(n2!=0){
      dataj_trt2 <- sim_data(n=n2,mu=mu_trt2_true,sd=sd_trt2_true,
                             omega=omega_true,lambda=lambda_trt2_true)
    } else{
      dataj_trt2 <- NULL } 
    
    if(n3!=0){
      dataj_trt3 <- sim_data(n=n3,mu=mu_trt3_true,sd=sd_trt3_true,
                             omega=omega_true,lambda=lambda_trt3_true) 
    } else{
      dataj_trt3 <- NULL }
    
    if(is.null(dataj_ctrl)){
      data_ctrl <- datacur_ctrl} else {
        data_ctrl <- rbind(datacur_ctrl,dataj_ctrl)}
    
    if(is.null(dataj_trt1)){
      data_trt1 <- datacur_trt1} else {
        data_trt1 <- rbind(datacur_trt1,dataj_trt1)}
    
    if(is.null(dataj_trt2)){
      data_trt2 <- datacur_trt2} else {
        data_trt2 <- rbind(datacur_trt2,dataj_trt2)}
    
    if(is.null(dataj_trt3)){
      data_trt3 <- datacur_trt3} else {
        data_trt3 <- rbind(datacur_trt3,dataj_trt3)}
    
    
    mcmcout_ctrl <- run_mcmc(d=data_ctrl$d,tau=data_ctrl$tau,B=B)
    mu_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"mu"] 
    sigma2_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"sigma2"]
    sd_ctrl <- sqrt(sigma2_ctrl)
    omega_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"omega"] 
    lambda_ctrl <- mcmcout_ctrl[seq(burnin+1,B,thin),"lambda"]
    rtn_ctrl <- (dnorm((ub-mu_ctrl)/sd_ctrl)-dnorm((lb-mu_ctrl)/sd_ctrl))/(pnorm((ub-mu_ctrl)/sd_ctrl)-pnorm((lb-mu_ctrl)/sd_ctrl))
    theta_ctrl <- (ub*omega_ctrl +  (1-omega_ctrl)*(mu_ctrl-sd_ctrl*rtn_ctrl))
    
    mcmcout_trt1 <- run_mcmc(d=data_trt1$d,tau=data_trt1$tau,B=B)
    mu_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"sigma2"]
    sd_trt1 <- sqrt(sigma2_trt1)
    omega_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"omega"] 
    lambda_trt1 <- mcmcout_trt1[seq(burnin+1,B,thin),"lambda"]
    rtn_trt1 <- (dnorm((ub-mu_trt1)/sd_trt1)-dnorm((lb-mu_trt1)/sd_trt1))/(pnorm((ub-mu_trt1)/sd_trt1)-pnorm((lb-mu_trt1)/sd_trt1))
    theta_trt1 <- (ub*omega_trt1 +  (1-omega_trt1)*(mu_trt1-sd_trt1*rtn_trt1))
    
    mcmcout_trt2 <- run_mcmc(d=data_trt2$d,tau=data_trt2$tau,B=B)
    mu_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"sigma2"]
    sd_trt2 <- sqrt(sigma2_trt2)
    omega_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"omega"] 
    lambda_trt2 <- mcmcout_trt2[seq(burnin+1,B,thin),"lambda"]
    rtn_trt2 <- (dnorm((ub-mu_trt2)/sd_trt2)-dnorm((lb-mu_trt2)/sd_trt2))/(pnorm((ub-mu_trt2)/sd_trt2)-pnorm((lb-mu_trt2)/sd_trt2))
    theta_trt2 <- (ub*omega_trt2 +  (1-omega_trt2)*(mu_trt2-sd_trt2*rtn_trt2))
    
    mcmcout_trt3 <- run_mcmc(d=data_trt3$d,tau=data_trt3$tau,B=B)
    mu_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"mu"] 
    sigma2_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"sigma2"]
    sd_trt3 <- sqrt(sigma2_trt3)
    omega_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"omega"] 
    lambda_trt3 <- mcmcout_trt3[seq(burnin+1,B,thin),"lambda"]
    rtn_trt3 <- (dnorm((ub-mu_trt3)/sd_trt3)-dnorm((lb-mu_trt3)/sd_trt3))/(pnorm((ub-mu_trt3)/sd_trt3)-pnorm((lb-mu_trt3)/sd_trt3))
    theta_trt3 <- (ub*omega_trt3 +  (1-omega_trt3)*(mu_trt3-sd_trt3*rtn_trt3))
    
    theta <- cbind(theta_ctrl,theta_trt1,theta_trt2,theta_trt3)
    n_cur <- c(nrow(data_ctrl),nrow(data_trt1),
               nrow(data_trt2),nrow(data_trt3))
    pvec <- trippa(theta,j,nj,n_total,n_cur=n_cur)
    #print(pvec)
    
    theta_mat <- cbind(theta_trt1,theta_trt2,theta_trt3)
    theta_mean <- c(mean(theta_trt1),mean(theta_trt2),mean(theta_trt3))
    theta_best <- theta_mat[,which.max(theta_mean)] 
    
    #clin_diff <- 1.5

    p_diff <- prob_diff(theta_best,theta_ctrl,clin_diff)
    #print(p_diff)
    
    datacur_ctrl <- data_ctrl
    datacur_trt1 <- data_trt1
    datacur_trt2 <- data_trt2
    datacur_trt3 <- data_trt3
    
    n0 <- n1 <- n2 <- n3 <- nj*ctrl_prop
    
    rm(dataj_ctrl)
    rm(dataj_trt1)
    rm(dataj_trt2)
    rm(dataj_trt3)
    
  }
  
  final_data_ctrl_tp[[r]] <- datacur_ctrl
  final_data_trt1_tp[[r]] <- datacur_trt1
  final_data_trt2_tp[[r]] <- datacur_trt2
  final_data_trt3_tp[[r]] <- datacur_trt3
  
  final_res_tp[,r,"ctrl_mu"] <- mu_ctrl 
  final_res_tp[,r,"ctrl_sigma2"] <- sigma2_ctrl 
  final_res_tp[,r,"ctrl_omega"] <- omega_ctrl 
  final_res_tp[,r,"ctrl_lambda"] <- lambda_ctrl
  
  final_res_tp[,r,"trt1_mu"] <- mu_trt1
  final_res_tp[,r,"trt1_sigma2"] <- sigma2_trt1
  final_res_tp[,r,"trt1_omega"] <- omega_trt1
  final_res_tp[,r,"trt1_lambda"] <- lambda_trt1
  
  final_res_tp[,r,"trt2_mu"] <- mu_trt2
  final_res_tp[,r,"trt2_sigma2"] <- sigma2_trt2
  final_res_tp[,r,"trt2_omega"] <- omega_trt2
  final_res_tp[,r,"trt2_lambda"] <- lambda_trt2
  
  final_res_tp[,r,"trt3_mu"] <- mu_trt3
  final_res_tp[,r,"trt3_sigma2"] <- sigma2_trt3
  final_res_tp[,r,"trt3_omega"] <- omega_trt3
  final_res_tp[,r,"trt3_lambda"] <- lambda_trt3
  
  
  end <- proc.time()
  print(end - start)
}    

all.end <- proc.time()
print(all.end - all.start)

save(final_res_R1,final_data_ctrl_R1,final_data_trt1_R1,
     final_data_trt2_R1,final_data_trt3_R1,
     final_res_R2,final_data_ctrl_R2,final_data_trt1_R2,
     final_data_trt2_R2,final_data_trt3_R2,
     final_res_R3,final_data_ctrl_R3,final_data_trt1_R3,
     final_data_trt2_R3,final_data_trt3_R3,
     final_res_fr,final_data_ctrl_fr,
     final_data_trt1_fr,final_data_trt2_fr,
     final_data_trt3_fr,
     final_res_ts,final_data_ctrl_ts,
     final_data_trt1_ts,final_data_trt2_ts,
     final_data_trt3_ts,
     final_res_tp,final_data_ctrl_tp,
     final_data_trt1_tp,final_data_trt2_tp,
     final_data_trt3_tp,file="res/final_data_res_mnn_omega03_pocock_R1000.RData")

#sink()

