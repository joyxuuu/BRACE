####### Run MCMC ######

### packages

library(MCMCpack)
library(truncnorm)

### update 08/26/2022: lb, ub, x, ind_d_tn, ind_d_peak

### constants:

alpha0 <- 1e-4
beta0 <- 1e-4
mu0 <- 0
sigma2_0 <- 10^4
lb <- 4-log(30) 
ub <- 4-log(2)  


### updating functions:
# for truncation part: learn from William Griffiths 2004 paper: "A Gibbs’ Sampler for the Parameters of a Truncated Multivariate Normal Distribution"

# d is vector, ldnt is the non-truncated log-transformed version of d (see Griffiths 2004)
# mu and sigma2 is the mean and variance on log scale

update_ldnt <- function(ld,mu,sigma2,eps=1e-5){
  ldstd <- (ld - mu)/sqrt(sigma2)
  x <- pnorm(ldstd)
  a <- pnorm((-log(lb)-mu)/sqrt(sigma2))
  b <- pnorm((-log(ub)-mu)/sqrt(sigma2))
  
  ldnt <- mu + sqrt(sigma2)*qnorm((x-a+eps)/(b-a+eps)) 
  
  #ldnt = mu + sqrt(sigma2)*qnorm((pnorm(log(d),mean=mu,sd=sqrt(sigma2))-pnorm(log(lb),mean=mu,sd=sqrt(sigma2)))/(pnorm(log(ub),mean=mu,sd=sqrt(sigma2))- pnorm(log(lb),mean=mu,sd=sqrt(sigma2)) ) ) 
  return(ldnt)
}

update_mu <- function(ld,sigma2){
  n <- length(ld)
  mean = (1/(1/sigma2_0 + n/sigma2))*(mu0/sigma2_0 + sum(ld)/sigma2)
  sd = sqrt(1/(1/sigma2_0 + n/sigma2)) 
  return(rnorm(1,mean=mean,sd=sd))
}

update_sigma2 <- function(ld,mu){
  n <- length(ld)
  shape=alpha0+n/2
  scale=beta0+sum((ld-mu)^2)/2
  #shape = n/2
  #scale = sum((ld-mu)^2)/2
  return(rinvgamma(1, shape=shape, scale = scale))
}

#update_zi <- function(di,omega,mu,sigma2){
#  if(di==1){
#    prob=omega/(omega+(1-omega)*dlnorm(x=1,meanlog=mu,sdlog=sqrt(sigma2))) 
#  } else{
#    prob=0
#  }
#  return(rbinom(1,1,prob=prob))
#}

update_omega <- function(z){
  shape1=1+sum(z)
  shape2=1+length(z)-sum(z)
  return(rbeta(1,shape1,shape2))
}

update_lambda <- function(tau){
  shape1=1+sum(tau)
  shape2=1+length(tau)-sum(tau)
  return(rbeta(1,shape1,shape2))
}


### run MCMC functions: for each arm separately


run_mcmc <- function(d,tau,B){
  
  #look for median of c(log2, log3) ~ log(2.5), test with n=1000 see stability
  
  n <- length(tau)
  d_live <- d[tau==0]
  n_live <- sum(tau==0)
  
#  ind_d_tn <- which(d_live <= -log(3)) # ?? use 2.5?
#  ind_d_peak <-   which(d_live > -log(3))
  
  ind_d_tn <- which(d_live <= 4-log(3)) # ?? use 2.5?
  ind_d_peak <-   which(d_live > 4-log(3))
  
  d_tn <- d_live[ind_d_tn]
  #d_peak <- d_live[ind_d_peak]
  
  mu.init <- mean(d_tn)
  sigma2.init <- var(d_tn)
  omega.init <- 0.5
  lambda.init <- (n-n_live)/n
  
  store.mat <- matrix(NA,nrow=B,ncol=4)
  colnames(store.mat) <- c("mu","sigma2","omega","lambda")
  
  mu <- store.mat[1,"mu"] <- mu.init
  sigma2 <- store.mat[1,"sigma2"] <- sigma2.init
  omega <- store.mat[1,"omega"] <- omega.init
  lambda <- store.mat[1,"lambda"] <- lambda.init
  
  #ind_1 <- which(d_tilde==1)
  #ind_non1 <- which(d_tilde!=1)
  z <- rbinom(n_live,1,omega)
  #ind_peak <- which(z==1)
  ind_tn <- which(z==0)
  
  #z1 <- z[ind_1]
  
  for(b in 2:B){
    #    mu <- store.mat[b-1,"mu"] 
    #    sigma2 <- store.mat[b-1,"sigma2"]
    #    omega <- store.mat[b-1,"omega"] 
    #    lambda <- store.mat[b-1,"lambda"] 
    
    #    if(length(z1)==sum(z1)){ ## i.e. all 1
    #      ind_non1 <-  ind_dnon1 } else {
    #        ind_non1 <-  c(ind_dnon1,ind_d1[z1==0])
    #}
    #    ind_1 <- setdiff(1:n_live,ind_non1)
    
    #ldnt <- update_ldnt(ld=ld,mu=mu,sigma2=sigma2)
    mu <- store.mat[b,"mu"] <- update_mu(ld=d_live[ind_tn],sigma2=sigma2)
    sigma2 <- store.mat[b,"sigma2"] <- update_sigma2(ld=d_live[ind_tn],mu=mu)
    
    z <- rep(0,n_live)
    #z[d==1] <- rbinom(sum(d==1),1,prob=omega/(omega+(1-omega)*dlnorm(x=1,meanlog=mu,sdlog=sqrt(sigma2))))
    
#    zz <- try(rbinom(length(ind_d_peak),1,
#                     prob=omega/(omega+(1-omega)*dtruncnorm(x=log(2),a=-log(lb),b=-log(ub), mean=mu,sd=sqrt(sigma2)))),silent=T)
    
#    if(class(zz)== "try-error"){
#      z[ind_d_peak] <- rbinom(length(ind_d_peak),1,omega)
#    } else{
#      z[ind_d_peak] <- zz
#    }
    
    zz <- try(rbinom(length(ind_d_peak),1,
                     prob=omega/(omega+(1-omega)*dtruncnorm(x=4-log(2),
                              a=lb,b=ub, mean=mu,sd=sqrt(sigma2)))),silent=T)
    
    if(class(zz)== "try-error"){
      z[ind_d_peak] <- rbinom(length(ind_d_peak),1,omega)
    } else{
      z[ind_d_peak] <- zz
    }
    
    #z <- sapply(d,FUN=function(di) {
    #   if(di!=1){return(0)} else {
    #     rbinom(1,1,prob=omega/(omega+(1-omega)*dlnorm(x=di,meanlog=mu,sdlog=sqrt(sigma2))) )
    #     }}, simplify = T)
    #z1 <- z[ind_d1]
    
    #ind_peak <- which(z==1)
    ind_tn <- which(z==0)
    
    #z <- rbinom(length(d),1,prob=omega/(omega+(1-omega)*dlnorm(x=d,meanlog=mu,sdlog=sqrt(sigma2))) )
    #z[d!=1] <- 0
    omega <- store.mat[b,"omega"] <- update_omega(z=z)
    #z <- sapply(d,update_zi,omega=omega,mu=mu,sigma2=sigma2,simplify = T)
    lambda <- store.mat[b,"lambda"] <- update_lambda(tau=tau)
    
    #if(b%%1000==0) print(b)
  }
  
  #store.mat[,"mu"] <- exp(store.mat[,"mu"])
  #store.mat[,"sigma2"] <- exp(store.mat[,"sigma2"])
  
  return(store.mat)
  
}





