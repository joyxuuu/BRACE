####### All functions ######

### packages

library(truncnorm)


## (1) simulate data 

# updated 08/26/2022: D = 4-log(30-Y)*(1-tau), so D(dead)=0, D(live)= (4-log(30), 4-log(2))

sim_data <- function(n,mu,sd,omega,lambda){
  
  #generate tau 
  tau <- rbinom(n,1,lambda)
  n_live <- sum(tau==0)
  ind_live <- which(tau==0)
  
  #generate d
  d <- rep(0,n)

  bin_mix <- rbinom(n_live,1,prob=omega) ## 0=from TN component, 1=from censored component
  n_nonone <- sum(bin_mix==0)
  n_one <- n_live - n_nonone
  
  if(n_nonone<2 | n_one<2 ){
    return(NULL)
  }
  ind_nonone <- which(bin_mix==0)
  ind_one <- which(bin_mix==1)
  
  d[ind_live][ind_one] <- 4-log(2)
  d[ind_live][ind_nonone] <- rtruncnorm(n_nonone,a=4-log(30),b=4-log(2),
                                               mean = mu, 
                                               sd = sd)  
  
  ## generate y 
  y <- rep(0,n)
  y[ind_live][ind_one] <- 28
  y[ind_live][ind_nonone] <- round(30-exp(-(d[ind_live][ind_nonone]-4)))
  
  data <- data.frame(y=y,tau=tau,d=d)

  return(data)
}


sim_data_init <- function(n,mu,sd,omega,lambda){
  
  
  #generate tau 
  tau <- rbinom(n,1,lambda)
  n_live <- sum(tau==0)
  ind_live <- which(tau==0)
  
  #generate d
  d <- rep(0,n)
  
  bin_mix <- rbinom(n_live,1,prob=omega) ## 0=from TN component, 1=from censored component
  n_nonone <- sum(bin_mix==0)
  n_one <- n_live - n_nonone

  ind_nonone <- which(bin_mix==0)
  ind_one <- which(bin_mix==1)
  
  d[ind_live][ind_one] <- 4-log(2)  
  d[ind_live][ind_nonone] <- rtruncnorm(n_nonone,a=4-log(30),b=4-log(2),
                                        mean = mu, 
                                        sd = sd)  
  
  ## generate y 
  y <- rep(0,n)
  y[ind_live][ind_one] <- 28
  y[ind_live][ind_nonone] <- round(30-exp(-(d[ind_live][ind_nonone])))
  
  data <- data.frame(y=y,tau=tau,d=d)
  
  return(data)
}


## (2) other allocation rules

# all these rules are already normalized as shown thus add up to 1 

fixed <- function(K){
  return(rep(1/K,K))
}

thompson <- function(theta,j,nj,n_total){
  #theta is BxK matrix theta[,1] is ctrl
  B <- nrow(theta)
  K <- ncol(theta)
  #assess posterior prob P(max(theta) = theta_k |data)
  c <- (j*nj)/(2*n_total) #c = jb/2T, where b= nj, T =n_total 
  max.ind <- apply(theta,1,which.max) ## simplified, should do all combn
  pj <- rep(NA,K)
  for(k in 1:K){
    pj[k] <- (sum(max.ind==k)/B)^c
  }
  return(pj/(sum(pj)))
}

trippa <- function(theta,j,nj,n_total,n_cur){
  #theta is BxK matrix theta[,1] is ctrl
  B <- nrow(theta)
  K <- ncol(theta)
  #assess posterior prob P(theta_k > theta_1 |data)
  gammaj <- 10*(j*nj/n_total)^0.75
  etaj <- 0.25*(j*nj/n_total)
  
  pbar <- rep(NA,K)
  pnum <- rep(NA,K-1)
  for(k in 1:K){
    if(k ==1){
      pbar[k] <- (1/(K-1))*exp(max(n_cur[-1],na.rm = T)-n_cur[1])^etaj ##??      
    } else {
      num <- as.numeric(outer(theta[,k],theta[,1],">"))
      pnum[k-1] <- (sum(num)/length(num))^gammaj
    }
  }
  pbar[-1] <- pnum/sum(pnum)
  return(pbar/(sum(pbar)))
  
}



## (3) evaluate prob diff (theta: the larger the better)

prob_best_3trtarm <- function(theta1,theta2,theta3){
  # by default assesses: P(theta1<theta2 & theta1<theta3)
  numerator <- as.numeric(outer(theta1,theta2,">"))*as.numeric(outer(theta1,theta3,">"))
  return(sum(numerator)/length(numerator))
}

prob_diff <- function(theta1,theta2,diff){
  numerator <- outer(theta1,theta2,FUN=function(x,y) x-y>diff)
  return(sum(numerator)/length(numerator))
}


### Functions to evaluate power, Type I error, etc ###

prob_diff <- function(theta1,theta_ctrl,diff){
  numerator <- outer(theta1,theta_ctrl,FUN=function(x,y) x-y>diff)
  return(sum(numerator)/length(numerator))
}


prob_diff2 <- function(theta1,theta2,theta_ctrl,diff){
  numerator <- as.numeric(outer(theta1,theta_ctrl+diff,">"))*as.numeric(outer(theta2,theta_ctrl+diff,">"))
  return(sum(numerator)/length(numerator))
}


prob_diff3 <- function(theta1,theta2,theta3,theta_ctrl,diff){
  numerator <- as.numeric(outer(theta1,theta_ctrl+diff,">"))*as.numeric(outer(theta2,theta_ctrl+diff,">"))*as.numeric(outer(theta3,theta_ctrl+diff,">"))
  return(sum(numerator)/length(numerator))
}




